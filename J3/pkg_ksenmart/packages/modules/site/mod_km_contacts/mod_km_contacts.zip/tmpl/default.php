<?php defined( '_JEXEC' ) or die; ?>
<div class="shop_contacts<?php echo $moduleclass_sfx; ?>">
    <p class="lead"><?php echo $params->get('shop_phone'); ?></p>
</div>