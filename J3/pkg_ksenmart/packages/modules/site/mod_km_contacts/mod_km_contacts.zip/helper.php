<?php defined('_JEXEC') or die;

/**
 * Class Module Helper
 * @author TakT
 */
class ModuleKm_ContactsHelper {

    /**
     * getData method
     * @param $params
     * @return array
     */
    static function getData($params) {
        $db = JFactory::getDbo();
        return array();
    }

}